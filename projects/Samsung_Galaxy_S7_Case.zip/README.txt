                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1412951
Samsung Galaxy S7 Case by rsavell is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

I just got my Galaxy S7 and tried to find a case to print but couldn't find one so I made one.  I printed this using PETG which is both and strong and flexible enough to work.

Enjoy and please post pictures of yours if you print one.

7/18/2016 -
After using the new case for a few days and from your feedback I updated the design.  I added slots on the back to provide better grip and let the heat out.  I added grips on the side and I also enlarged and better positioned some of the holes

# Print Settings

Printer: PowerSpec 3D Pro (Flashforge)
Rafts: No
Supports: No
Resolution: 0.15mm Layer height
Infill: 75%

Notes: 
I set the bed temp to 80c and the filament to 240c with a 0.15mm layer height, 95% extrusion multiplier and printed at 50mm/s using a retraction of 4mm which seems to work great and provides a smoother finish.